
function payWithPayPal(amount, serviceName) {
    alert(`Redirigiendo al pago de ${serviceName} por $${amount}. Esta función puede ser integrada con PayPal o Stripe.`);
    window.location.href = 'https://www.paypal.com';
}
